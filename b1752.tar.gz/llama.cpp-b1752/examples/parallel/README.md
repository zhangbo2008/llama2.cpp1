# llama.cpp/example/parallel

Simplified simulation of serving incoming requests in parallel
